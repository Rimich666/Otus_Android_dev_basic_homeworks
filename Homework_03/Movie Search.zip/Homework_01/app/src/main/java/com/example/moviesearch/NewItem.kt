package com.example.moviesearch

data class NewItem(val name: String, val description: String, val pictures: String, var Selected: Boolean)